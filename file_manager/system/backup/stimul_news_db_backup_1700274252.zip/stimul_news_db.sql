#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `a_uid` int NOT NULL AUTO_INCREMENT,
  `a_name` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_surname` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_email` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_username` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_password` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_img` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_role` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `a_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`a_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin` (`a_uid`, `a_name`, `a_surname`, `a_email`, `a_username`, `a_password`, `a_img`, `a_role`, `a_status`) VALUES (1, 'Murad', 'Gazymagomedov', 'murad.dev@bk.ru', 'gmurad97', '3e39b3844837bdefc8017fbcb386ea302af877fb17baa09d0a1bd34b67bbf2b34fba314bbcab450f5f3f73771b7aea956ba3320defda029723f4fdff7dfa007b', '3ce22b45bce9fad2ef82c9da862d34fa.jpg', '999', 1);
INSERT INTO `admin` (`a_uid`, `a_name`, `a_surname`, `a_email`, `a_username`, `a_password`, `a_img`, `a_role`, `a_status`) VALUES (4, 'Rza', 'Talibov', 'rza.t@code.edu.az', 'rza.talibov', '3e39b3844837bdefc8017fbcb386ea302af877fb17baa09d0a1bd34b67bbf2b34fba314bbcab450f5f3f73771b7aea956ba3320defda029723f4fdff7dfa007b', '644eb3423aa6a506f57a05ff65f344e6.jpg', '666', 1);


#
# TABLE STRUCTURE FOR: branding
#

DROP TABLE IF EXISTS `branding`;

CREATE TABLE `branding` (
  `b_uid` int NOT NULL AUTO_INCREMENT,
  `b_data` json NOT NULL,
  PRIMARY KEY (`b_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `branding` (`b_uid`, `b_data`) VALUES (1, '{\"favicon\": {\"file_ext\": \".ico\", \"file_name\": \"fefa31cf1996948cf5f459e1f2c99aaa.ico\", \"file_type\": \"image/vnd.microsoft.icon\"}, \"logo_dark\": {\"file_ext\": \".png\", \"file_name\": \"0d6b47c1089e410be17464e7426441c5.png\", \"file_type\": \"image/png\", \"visibility\": true}, \"logo_light\": {\"file_ext\": \".png\", \"file_name\": \"08dad5295c41af70dc2c0797be47a792.png\", \"file_type\": \"image/png\", \"visibility\": true}, \"title_prefix\": \"U3RpbXVsIE5ld3M=\"}');


#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `c_uid` int NOT NULL AUTO_INCREMENT,
  `c_name` json NOT NULL,
  `c_bg_color` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `c_img` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `c_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`c_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`c_uid`, `c_name`, `c_bg_color`, `c_img`, `c_status`) VALUES (1, '{\"az\": \"SMmZeWF0IHTJmXJ6aQ==\", \"en\": \"TGlmZSBTdHlsZQ==\", \"ru\": \"0KHRgtC40LvRjCDQttC40LfQvdC4\"}', '#741b47', '2e8b941f7c07579c32f0b18a2b12ec4f.jpg', 1);
INSERT INTO `categories` (`c_uid`, `c_name`, `c_bg_color`, `c_img`, `c_status`) VALUES (2, '{\"az\": \"Rm90b2dyYWZpeWE=\", \"en\": \"UGhvdG9ncmFwaHk=\", \"ru\": \"0KTQvtGC0L7Qs9GA0LDRhNC40Y8=\"}', '#f1c232', 'deef36bb4eee0ebeb55542936a425367.jpg', 1);


#
# TABLE STRUCTURE FOR: contacts
#

DROP TABLE IF EXISTS `contacts`;

CREATE TABLE `contacts` (
  `c_uid` int NOT NULL AUTO_INCREMENT,
  `c_data` json NOT NULL,
  PRIMARY KEY (`c_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `contacts` (`c_uid`, `c_data`) VALUES (3, '{\"social\": {\"twitter\": {\"link\": \"aHR0cHM6Ly90d2l0dGVyLmNvbS8=\", \"status\": false}, \"youtube\": {\"link\": \"aHR0cHM6Ly95b3V0dWJlLmNvbS8=\", \"status\": false}, \"facebook\": {\"link\": \"aHR0cHM6Ly9mYWNlYm9vay5jb20v\", \"status\": false}, \"instagram\": {\"link\": \"aHR0cHM6Ly9pbnN0YWdyYW0uY29tL2dtdXJhZDk3Lw==\", \"status\": true}, \"pinterest\": {\"link\": \"aHR0cHM6Ly9waW50ZXJlc3QuY29tLw==\", \"status\": false}, \"google_plus\": {\"link\": \"aHR0cHM6Ly9nb29nbGUuY29tLw==\", \"status\": false}}, \"information\": {\"mail\": {\"info\": \"bXVyYWQuZGV2QGJrLnJ1\", \"status\": true}, \"phone\": {\"info\": \"Kzk5NDU1OTkxODU0MA==\", \"status\": true}, \"address\": {\"info\": \"NDQgQ8mZZsmZciBDYWJiYXJsxLEga8O8w6fJmXNpLCBCYWvEsSAxMDY1\", \"status\": true}}}');


#
# TABLE STRUCTURE FOR: gallery
#

DROP TABLE IF EXISTS `gallery`;

CREATE TABLE `gallery` (
  `g_uid` int NOT NULL AUTO_INCREMENT,
  `g_img` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`g_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: news
#

DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `n_uid` int NOT NULL AUTO_INCREMENT,
  `n_title` json NOT NULL,
  `n_short` json NOT NULL,
  `n_full` json NOT NULL,
  `n_preview_img` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `n_category_uid` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `n_created_date` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `n_created_time` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `n_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`n_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (17, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', '99a45f9c6ca4d4721fc9d37c40b29043.jpg', '2', '11.11.2023', '03:49', 1);
INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (18, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', 'e0d8c15a79508cc08c4817845e769c46.jpg', '2', '11.11.2023', '03:49', 1);
INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (19, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', '1b20cc68f24032e3493d1fa2101cd008.jpg', '2', '11.11.2023', '03:49', 1);
INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (20, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', '0817e27197a8161e0664f7fa6b31ebf5.jpg', '2', '11.11.2023', '03:49', 1);
INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (21, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', 'a5ae0e2f1a39557da2c61a2c9b533f7a.jpg', '2', '11.11.2023', '03:49', 1);
INSERT INTO `news` (`n_uid`, `n_title`, `n_short`, `n_full`, `n_preview_img`, `n_category_uid`, `n_created_date`, `n_created_time`, `n_status`) VALUES (22, '{\"az\": \"0LLQsNC/\", \"en\": \"0LLQsNC/0LLQsA==\", \"ru\": \"0LLQsNC/\"}', '{\"az\": \"0LLQsNC/0LLQsA==\", \"en\": \"0L/QstCw0L/QstCw\", \"ru\": \"0LLQsNC/0LLQsNC/0LLQsA==\"}', '{\"az\": \"PHA+0L/QstCw0L/QstCw0L/QstCw0L/QsNCyPC9wPg0K\", \"en\": \"PHA+0L/QstCw0L/QstCwPC9wPg0K\", \"ru\": \"PHA+0LLQsNC/0LLQsNC/0LLQsNC/0LLQsDwvcD4NCg==\"}', 'd636c90abcb32d2ec31813c8a04d5be5.jpg', '2', '11.11.2023', '03:49', 1);


#
# TABLE STRUCTURE FOR: partners
#

DROP TABLE IF EXISTS `partners`;

CREATE TABLE `partners` (
  `p_uid` int NOT NULL AUTO_INCREMENT,
  `p_title` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `p_link` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `p_img` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `p_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`p_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `partners` (`p_uid`, `p_title`, `p_link`, `p_img`, `p_status`) VALUES (6, 'LUKOIL AZ', 'https://lukoil.az/', 'a9ecbd4784ec94bb6e461b6d68a61f84.png', 1);
INSERT INTO `partners` (`p_uid`, `p_title`, `p_link`, `p_img`, `p_status`) VALUES (7, 'SOCAR AZ', 'https://socar.az/', '192a16ea3347d28fcf62a1527960499e.png', 1);
INSERT INTO `partners` (`p_uid`, `p_title`, `p_link`, `p_img`, `p_status`) VALUES (8, 'MARCO POLO MARINE', 'https://marcopolomarine.com.sg/', '339f8bad8c5063dd9c3e9a09718820e4.png', 0);
INSERT INTO `partners` (`p_uid`, `p_title`, `p_link`, `p_img`, `p_status`) VALUES (9, 'TURKMEN PETROLEUM', 'http://turkmenpetroleum.com/', 'e209033bdb3c79136dc43c3a68ccd7ee.png', 0);


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `s_uid` int NOT NULL AUTO_INCREMENT,
  `s_data` json NOT NULL,
  PRIMARY KEY (`s_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`s_uid`, `s_data`) VALUES (9, '{\"dark_mode_cms\": true, \"under_construction\": true}');


#
# TABLE STRUCTURE FOR: slider
#

DROP TABLE IF EXISTS `slider`;

CREATE TABLE `slider` (
  `s_uid` int NOT NULL AUTO_INCREMENT,
  `s_data` json NOT NULL,
  PRIMARY KEY (`s_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `slider` (`s_uid`, `s_data`) VALUES (9, '{\"slider_info\": {\"slider_img\": \"1b8921a333bf28fd7169f31e7845e8c9.jpg\", \"slider_status\": false, \"slider_large_text\": \"MTI=\", \"slider_small_text\": \"MTI=\", \"slider_large_text_color\": \"#00aa00\", \"slider_small_text_color\": \"#00aa00\"}, \"slider_type\": \"slider_custom\"}');
INSERT INTO `slider` (`s_uid`, `s_data`) VALUES (10, '{\"slider_info\": {\"slider_uid\": \"18\", \"slider_status\": true}, \"slider_type\": \"slider_news\"}');


#
# TABLE STRUCTURE FOR: subscribers
#

DROP TABLE IF EXISTS `subscribers`;

CREATE TABLE `subscribers` (
  `s_uid` int NOT NULL AUTO_INCREMENT,
  `s_email` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `s_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`s_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `subscribers` (`s_uid`, `s_email`, `s_status`) VALUES (1, 'murad.dev@bk.ru', 1);
INSERT INTO `subscribers` (`s_uid`, `s_email`, `s_status`) VALUES (2, 'vvxakervv@bk.ru', 1);
INSERT INTO `subscribers` (`s_uid`, `s_email`, `s_status`) VALUES (3, 'agurbanff@gmail.com', 0);


#
# TABLE STRUCTURE FOR: topbar
#

DROP TABLE IF EXISTS `topbar`;

CREATE TABLE `topbar` (
  `t_uid` int NOT NULL AUTO_INCREMENT,
  `t_data` json NOT NULL,
  PRIMARY KEY (`t_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `topbar` (`t_uid`, `t_data`) VALUES (1, '{\"topbar_date\": true, \"topbar_self\": true, \"topbar_time\": true, \"topbar_weather\": true}');


